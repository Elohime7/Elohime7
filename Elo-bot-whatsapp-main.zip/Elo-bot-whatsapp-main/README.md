 <p align="center">  
  <a href="">
    <img alt="PRINCE" width="600" height="350" src="https://i.imgur.com/iI086tX.jpeg">
  </a>
</p>



<p align="center">
<a href="https://github.com/PRINCE-GDS/PRINCE-MD-BOT"><img title="Author" src="https://img.shields.io/badge/𝑷𝑹𝑰𝑵𝑪𝑬 𝑴𝑫 𝑩𝑶𝑻-black?style=for-the-badge&logo=github"></a>
<p/>

<p align="center">
<a href="https://github.com/PRINCE-GDS?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/PRINCE-GDS?label=Followers&style=social"></a>
<a href="https://github.com/PRINCE-GDS/PRINCE-MD-BOT/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/PRINCE-GDS/PRINCE-MD-BOT?&style=social"></a>
<a href="https://github.com/PRINCE-GDS/PRINCE-MD-BOT/network/members"><img title="Fork" src="https://img.shields.io/github/forks/PRINCE-GDS/PRINCE-MD-BOT?style=social"></a>
<a href="https://github.com/PRINCE-GDS/PRINCE-MD-BOT/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/PRINCE-GDS/PRINCE-MD-BOT?label=Watching&style=social"></a>
</p>


 <h1 align="center">𝑷𝑹𝑰𝑵𝑪𝑬-𝑴𝑫-𝑩𝑶𝑻</h1>

****



***

### 💠𝙋𝘼𝙄𝙍 𝘾𝙊𝘿𝙀 
### Click and wait a little bit for loading the site.
<p align="left">
<a href="https://gds-md-pair.onrender.com/"><img height= "30" title="Author" src="https://img.shields.io/badge/SESSION ID-black?style=for-the-badge&logo=render"></a>
<p/>


### 💠𝙋𝘼𝙄𝙍 𝘼𝙉𝘿 𝙌𝙍 𝘾𝙊𝘿𝙀
### Click and wait a little bit for loading the site.
<p align="left">
<a href="https://princebotzsession.onrender.com"><img height= "30" title="Author" src="https://img.shields.io/badge/SESSION ID-skyblue?style=for-the-badge&logo=render"></a>
<p/>
  
𝘐𝘧 𝘱𝘢𝘪𝘳 𝘤𝘰𝘥𝘦 𝘥𝘰𝘯'𝘵 𝘸𝘰𝘳𝘬 𝘵𝘩𝘦𝘯 𝘴𝘤𝘢𝘯 𝘘𝘙 𝘧𝘰𝘳 𝘴𝘦𝘴𝘴𝘪𝘰𝘯 𝘐𝘋
### 💠𝙌𝙍 𝙎𝘾𝘼𝙉
<p align="left">
<a href="https://princebotqr.onrender.com/"><img height= "30" title="Author" src="https://img.shields.io/badge/SESSION ID-black?style=for-the-badge&logo=render"></a>
<p/>

****


****

### 🟣 𝘿𝙀𝙋𝙇𝙊𝙔 𝙊𝙉 𝙃𝙀𝙍𝙊𝙆𝙐 🟣
  𝘐𝘧 𝘠𝘰𝘶 𝘥𝘰𝘯'𝘵 𝘩𝘢𝘷𝘦 𝘢𝘯 𝘢𝘤𝘤𝘰𝘶𝘯𝘵 𝘪𝘯 𝘏𝘦𝘳𝘰𝘬𝘶. 𝘊𝘳𝘦𝘢𝘵𝘦 𝘢𝘯 𝘢𝘤𝘤𝘰𝘶𝘯𝘵.
  
  💠[𝘊𝘓𝘐𝘊𝘒 𝘏𝘌𝘙𝘌](https://signup.heroku.com)
  
👇---------------------ɢᴅs-ᴍᴅ---------------------👇

🟣 𝘿𝙀𝙋𝙇𝙊𝙔 𝙉𝙊𝙒 👇

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/PRINCE-GDS/PRINCR-MD-BOT) 

  
****


### 🟤 𝘿𝙀𝙋𝙇𝙊𝙔 𝙊𝙉 𝙍𝙀𝙋𝙇𝙄𝙏 🟤
𝘐𝘧 𝘠𝘰𝘶 𝘥𝘰𝘯'𝘵 𝘩𝘢𝘷𝘦 𝘢𝘯 𝘢𝘤𝘤𝘰𝘶𝘯𝘵 𝘪𝘯 𝘙𝘦𝘱𝘭𝘪𝘵. 𝘊𝘳𝘦𝘢𝘵𝘦 𝘢𝘯 𝘢𝘤𝘤𝘰𝘶𝘯𝘵.
  
  💠 [𝘊𝘓𝘐𝘊𝘒 𝘏𝘌𝘙𝘌](https://replit.com/signup) 
  
👇-------------------ɢᴅs-ᴍᴅ-----------------------👇

 🟤 𝘿𝙀𝙋𝙇𝙊𝙔 𝙉𝙊𝙒 👇
    <br>
<p align="left"><a href="https://repl.it/github/PRINCE-GDS/PRINCE-MD-BOT"> <img src="https://img.shields.io/badge/Deploy%20To%20Replit-gray?style=for-the-badge&logo=replit" height="30"/></a></p>

****

### ⚫ 𝘿𝙀𝙋𝙇𝙊𝙔 𝙊𝙉 𝙆𝙊𝙔𝙀𝘽 ⚫
𝘪𝘧 𝘺𝘰𝘶 𝘥𝘰𝘯'𝘵 𝘩𝘢𝘷𝘦 𝘢𝘯 𝘢𝘤𝘤𝘰𝘶𝘯𝘵 𝘰𝘯 𝘒𝘰𝘺𝘦𝘣. 𝘊𝘳𝘦𝘢𝘵𝘦 𝘢𝘯 𝘢𝘤𝘤𝘰𝘶𝘯𝘵.

💠[𝘊𝘓𝘐𝘊𝘒 𝘏𝘌𝘙𝘌](https://app.koyeb.com/auth/signup)

👇--------------------ɢᴅs-ᴍᴅ----------------------👇
   
⚫ 𝘿𝙀𝙋𝙇𝙊𝙔 𝙉𝙊𝙒 👇
   <br>
  <p align="left"><a href="https://app.koyeb.com/apps/deploy?type=git&repository=github.com%2FPRINCE-GDS%2FPRINCE-MD-BOT&branch=main&nameprincegds&builder=dockerfile&env[DATABASE_URL]=&env[SESSION_ID]=your+sessionid+here&env[MODE]=public&env=[autoRead]=false&env[statusview]=false&env[REMOVEBG_KEY]=your+rmbg+key&env[antidelete]=false"> <img src="https://www.koyeb.com/static/images/deploy/button.svg" height="40"/></a></p>

****

------------------
### ☁️ 𝘿𝙀𝙋𝙇𝙊𝙔 𝙏𝙊 𝙍𝙀𝙉𝘿𝙀𝙍
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://dashboard.render.com/blueprint/new?repo=https%3A%2F%2Fgithub.com%2FPRINCE-GDS%2FGDS-MD) 

***

### 🟢 𝙎𝙐𝙋𝙋𝙊𝙍𝙏 𝙂𝙍𝙊𝙐𝙋 𝙇𝙄𝙉𝙆 🟢
   <p align="left">
      <a href="https://chat.whatsapp.com/Jo5bmHMAlZpEIp75mKbwxP"><img height= "40" length= "10" title="Author" src="https://img.shields.io/badge/Support Group-25D366?style=for-the-badge&logo=whatsApp&logoColor=white"></a>
     <p/>
       
***

### 𝗟𝗜𝗖𝗘𝗡𝗦𝗘: [MIT](https://en.wikipedia.org/wiki/MIT_License)
 
  
----
### 💠 [`𝐿𝐴𝑁𝐺𝑈𝐴𝐺𝐸𝑆 𝐴𝑉𝐴𝐼𝐿𝐴𝐵𝐿𝐸 𝐹𝑂𝑅 𝑃𝑅𝐼𝑁𝐶𝐸-𝑀𝐷`]
#### 🌐 Arabic = ar 
#### 🌐 Urdu = ur
#### 🌐 English Global = en
#### 🌐 Bahasa Indonesia = id
#### 🌐 Portuguese = pt
#### 🌐 Spanish = es









### 💌-----------------------👇🏻𝗖𝗟𝗜𝗖𝗞 𝗛𝗘𝗥𝗘👇🏻-------------------------💌


<p align="left">
<a href="https://gd-sdeploy.vercel.app/PRINCE-MD-WEB-main/projects/index.html"><img height= "70" title="Author" src="https://img.shields.io/badge/𝗣𝗥𝗜𝗡𝗖𝗘 𝗕𝗢𝗧 𝗔𝗟𝗟 𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧𝗦-032B44?style=for-the-badge&logo=vercel"></a>
<p/>


****





